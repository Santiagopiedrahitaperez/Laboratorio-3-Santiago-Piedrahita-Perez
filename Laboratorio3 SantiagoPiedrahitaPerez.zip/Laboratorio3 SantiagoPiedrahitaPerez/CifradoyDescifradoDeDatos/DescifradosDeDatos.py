from cryptography.fernet import Fernet
import os

extension = 'IUEHackeoEtico202302SantiagoPiedrahitaPerez'

#Cargamos la llave generada
def cargar_llave():
    return open('PiedrahitaPerezSantiago.key','rb').read()

#Descifrar y restaurar los archivos
def descifrar(items, key):
    f = Fernet(key)
    for item in items:
        if item.endswith('.' + extension):
            original_name = item.replit('-',1)[0]
            # Leer el archivo cifrado
            with open(item, 'rb') as file:
                file_data = file.read()
            decrypted_data = f.decrypt(file_data)
            # Escribir el archivo descifrado
            with open(original_name, 'wb') as file: 
                file.write(decrypted_data)
            # Eliminar el archivo cifrado
            os.remove(item)
            
            
if __name__ == ('__main__'): 
    path_to_decrypt = 'C:\Users\Santi\OneDrive\Documentos\IUEHE\2023-02\CifradoyDescifradoDeDatos'
    items = os.listdir(path_to_decrypt)
    full_path = [os.path.join(path_to_decrypt, item) for item in items]
    
    key = cargar_llave()
    descifrar(full_path, key)
    
    with open(os.path.join(path_to_decrypt,'README.txt','w')) as file:
        file.write('Sus archivos han sido descifrados')